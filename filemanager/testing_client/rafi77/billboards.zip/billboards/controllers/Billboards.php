<?php defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Billboards Controller.
 */
class Billboards extends Admin_Controller
{
    protected $user_can_manage_invoices = false;

    /**
     * Controler __construct function to initialize options.
     */
    public function __construct()
    {
        parent::__construct();
        is_active_module('billboards');
        if (empty(my_id())) {
            redirect('login');
        }
        
        $this->load->model('billboards_model');

        // load custom css & js assets
        // $this->module->css = [
        //     // 'modules/' . BILLBOARDS_MODULE . '/assets/css/styles.css',
        // ];
        $css_file = 'modules/' . BILLBOARDS_MODULE . '/assets/css/styles.css';
        array_push($this->module->css, $css_file);
        $js_file = 'modules/' . BILLBOARDS_MODULE . '/assets/js/scripts.js';
        array_push($this->module->js, $js_file);

        $this->profile = $profile = profile();
        if (empty($profile)) {
            redirect('login');
        } else {
            $role = $profile->role_id;
            if ($role == 2) { // check client menu permission
                $client_menu = get_row('tbl_client_role', array('user_id' => $profile->user_id, 'menu_id' => '19'));
                if (empty($client_menu)) {
                    redirect('login');
                }
                $this->view = 'client/';
            } elseif ($role != 1) { // check staff menu permission
                if (!empty($profile->designations_id)) {
                    $user_menu = get_row('tbl_user_role', array('designations_id' => $profile->designations_id, 'menu_id' => '139'));
                    if (empty($user_menu)) {
                        redirect('login');
                    }
                }
                $this->view = 'admin/';
            } else {
                $this->view = 'admin/';
            }
        }

        // $this->user_can_manage_invoices = can_do(162);
        $this->user_can_manage_invoices = can_action('13', 'edited');
    }
    
    
    /**
     * Go to Billboards home page.
     *
     * @return view
     */
    public function index($id = null, $opt = null)
    {
        $data['title'] = lang('all_billboards');
        if (!empty($id) && is_numeric($id)) {
            $data['active'] = 2;
            $data['items_info'] = $this->billboards_model->check_by(array('billboard_id' => $id), 'tbl_billboards');
        } else {
            $data['active'] = 1;
        }
        $data['dropzone'] = 1;

        // get all country
        $this->billboards_model->_table_name = "tbl_countries"; //table name
        $this->billboards_model->_order_by = "id";
        $data['countries'] = $this->billboards_model->get();

        // get all estimates by supplier id
        $this->billboards_model->_table_name = "tbl_client"; //table name
        $this->billboards_model->_order_by = "name";
        $data['all_clients'] = $this->billboards_model->get();
        
        $data['subview'] = $this->load->view('billboards', $data, TRUE);
        $this->load->view('admin/_layout_main', $data); //page load
        // $this->load->view($this->view . '_layout_main', $data);
    }

    public function BillboardsList($group_id = null, $type = null)
    {
        if ($this->input->is_ajax_request()) {
            $this->load->model('datatables');
            $this->datatables->table = 'tbl_billboards';
            $this->datatables->join_table = array('tbl_billboards_occupancy', 'tbl_project');
            $this->datatables->join_where = array('tbl_billboards_occupancy.billboard_id=tbl_billboards.billboard_id', 'tbl_project.project_id=tbl_billboards_occupancy.project_id');
            $this->datatables->select = 'tbl_billboards.*, tbl_billboards_occupancy.project_id, tbl_billboards_occupancy.status,';
            // $custom_field = custom_form_table_search(18);
            $custom_field = [];
            $action_array = array('billboard_id');
            $main_column = array('billboard_id', 'billboard_name', 'location', 'city', 'region', 'faces', 'dimension', 'type', 'ownership', 'cost_per_month', 'occupancy');
            $result = array_merge($main_column, $custom_field, $action_array);
            $this->datatables->column_order = $result;
            $this->datatables->column_search = $result;

            $this->datatables->order = array('tbl_billboards.billboard_id' => 'DESC');

            // get all invoice
            if (!empty($type) && $type == 'by_client') {
                $where = array('tbl_billboards_occupancy.project_id' => $group_id);
            } else if (!empty($type) && $type == 'by_location') {
                $where = array('tbl_billboards.city' => $group_id);
            } else if (!empty($type) && $type == 'by_occupancy') {
                $where = array('tbl_billboards.occupancy' => $group_id);
            } else {
                $where = null;
            }
            $fetch_data = make_datatables($where);

            $data = array();

            $can_edit_invoice = can_action('13', 'edited');
            $can_delete_invoice = can_action('13', 'deleted');
            foreach ($fetch_data as $_key => $v_items) {
                $action = null;
                $billboard_name = !empty($v_items->billboard_name) ? $v_items->billboard_name : '';

                $sub_array = array();

                if($v_items->occupancy == 'occupied') { 
                    $occupancy = '<span class="btn btn-success btn-xs">'.ucfirst($v_items->occupancy).'</span>';
                } else { 
                    $occupancy = '<span class="btn btn-warning btn-xs">'.ucfirst($v_items->occupancy).'</span>';
                }
                if($v_items->status == 1) { 
                    $status = 'Active';
                } else { 
                    $status = 'Inactive';
                }

                if (!empty($can_delete_invoice)) {
                    $sub_array[] = '<div class="checkbox c-checkbox" ><label class="needsclick"> <input value="' . $v_items->billboard_id . '" type="checkbox"><span class="fa fa-check"></span></label></div>';
                }
                // $sub_array[] = '<a data-toggle="modal" data-target="#myModal_extra_lg" href="' . base_url('admin/billboards/details/' . $v_items->billboard_id) . '"><strong class="block">' . $billboard_name . '</strong></a>';
                $sub_array[] = '<a href="' . base_url('admin/billboards/details/' . $v_items->billboard_id) . '"><strong class="block">' . $billboard_name . '</strong></a>';

                $sub_array[] = ucwords($v_items->location);
                $sub_array[] = ucwords($v_items->city);
                $sub_array[] = ucwords($v_items->region);
                $sub_array[] = ucwords($v_items->type);
                $sub_array[] = $v_items->dimension;
                $sub_array[] = ucwords($v_items->ownership);
                
                if (!empty(admin())) {
                    $sub_array[] = display_money($v_items->cost_per_month, default_currency());
                }
                // occupancy
                $sub_array[] = $occupancy;
                // $sub_array[] = display_money($v_items->unit_cost, default_currency());
                /*$sub_array[] = $v_items->unit_type;
                if (!is_numeric($v_items->tax_rates_id)) {
                    $tax_rates = json_decode($v_items->tax_rates_id);
                } else {
                    $tax_rates = null;
                }
                $rates = null;
                if (!empty($tax_rates)) {
                    if (is_array($tax_rates)) {
                        foreach ($tax_rates as $key => $tax_id) {
                            $taxes_info = $this->db->where('tax_rates_id', $tax_id)->get('tbl_tax_rates')->row();
                            if (!empty($taxes_info)) {
                                $rates .= $key + 1 . '. ' . $taxes_info->tax_rate_name . '&nbsp;&nbsp; (' . $taxes_info->tax_rate_percent . '% ) <br>';
                            }
                        }
                    } else {
                        $rates = $this->db->where('tax_rates_id', $tax_rates)->get('tbl_tax_rates')->row()->tax_rate_name;
                    }
                }
                $sub_array[] = $rates;

                $sub_array[] = (!empty($v_items->customer_group) ? '<span class="tags">' . $v_items->customer_group . '</span>' : ' ');
                $custom_form_table = custom_form_table(18, $v_items->billboard_id);

                if (!empty($custom_form_table)) {
                    foreach ($custom_form_table as $c_label => $v_fields) {
                        $sub_array[] = $v_fields;
                    }
                }*/
                
                // $action .= btn_view_modal_large('admin/billboards/details/' . $v_items->billboard_id) . ' ';
                $action .= btn_view('admin/billboards/details/' . $v_items->billboard_id) . ' ';

                if (!empty($can_edit_invoice)) {
                    $action .= btn_edit('admin/billboards/index/' . $v_items->billboard_id) . ' ';
                }
                if (!empty($can_delete_invoice)) {
                    $action .= ajax_anchor(base_url("admin/billboards/delete/$v_items->billboard_id"), "<i class='btn btn-xs btn-danger fa fa-trash-o'></i>", array("class" => "", "title" => lang('delete'), "data-fade-out-on-success" => "#table_" . $_key)) . ' ';
                }

                $sub_array[] = $action;
                $data[] = $sub_array;
            }

            render_table($data);
        } else {
            redirect('admin/dashboard');
        }
    }

    public function details($id = NULL)
    {
        $data['title'] = lang('billboard_details');
        $data['active'] = 1;
        if (!empty($id)) {
            $data['item_info'] = $this->billboards_model->check_by(array('billboard_id' => $id), 'tbl_billboards');
        }
        $data['subview'] = $this->load->view('details', $data, true);
        $this->load->view('admin/_layout_main', $data); //page load
        // $this->load->view('admin/_layout_modal_lg', $data); //page load
    }

    public function save($id = NULL)
    {
        $data = $this->billboards_model->array_from_post(array('billboard_name', 'description', 'type', 'dimension', 'faces', 'orientation', 'ownership', 'cost_per_month', 'unit_type', 'location', 'city', 'region', 'country', 'latitude', 'longitude', 'status'));
        
        // check for duplicate item
        $where = array('billboard_name' => $data['billboard_name']);
        // duplicate value check in DB
        // if id exist in db update data
        if (!empty($id)) {
            $billboard_id = array('billboard_id !=' => $id);
        // if id is not exist then set id as null
        } else {
            $billboard_id = null;
        }
        // check whether this input data already exist or not
        $check_items = $this->billboards_model->check_update('tbl_billboards', $where, $billboard_id);
        // if input data already exist show error alert
        if (!empty($check_items)) {
            // massage for user
            $type = 'error';
            $msg = "<strong>" . $data['billboard_name'] . '</strong>  ' . lang('already_exist');
        } else { // save and update query          

            $upload_file = array();

            $files = $this->input->post("files", true);

            $target_path = getcwd() . "/uploads/";
            // process the fiiles which has been uploaded by dropzone
            if (!empty($files) && is_array($files)) {
                foreach ($files as $key => $file) {
                    if (!empty($file)) {
                        $file_name = $this->input->post('file_name_' . $file, true);
                        $new_file_name = move_temp_file($file_name, $target_path);
                        $file_ext = explode(".", $new_file_name);
                        $is_image = check_image_extension($new_file_name);
                        $size = $this->input->post('file_size_' . $file, true) / 1000;
                        if (!empty($new_file_name)) {
                            $up_data = array(
                                "fileName" => $new_file_name,
                                "path" => "uploads/" . $new_file_name,
                                "fullPath" => getcwd() . "/uploads/" . $new_file_name,
                                "ext" => '.' . end($file_ext),
                                "size" => round($size, 2),
                                "is_image" => $is_image,
                            );
                            array_push($upload_file, $up_data);
                        }
                    }
                }
            }
            $fileName   = $this->input->post('fileName', true);
            $path       = $this->input->post('path', true);
            $fullPath   = $this->input->post('fullPath', true);
            $size       = $this->input->post('size', true);
            $is_image   = $this->input->post('is_image', true);

            if (!empty($fileName)) {
                foreach ($fileName as $key => $name) {
                    $old['fileName']    = $name;
                    $old['path']        = $path[$key];
                    $old['fullPath']    = $fullPath[$key];
                    $old['size']        = $size[$key];
                    $old['is_image']    = $is_image[$key];

                    array_push($upload_file, $old);
                }
            }
            if (!empty($upload_file)) {
                $data['image'] = json_encode($upload_file);
            } else {
                $data['image'] = null;
            }

            // calculating tax rates
            $tax_rates = $this->input->post('tax_rates_id', true);
            $total_tax = 0;
            if (!empty($tax_rates)) {
                foreach ($tax_rates as $tax_id) {
                    $tax_info = $this->db->where('tax_rates_id', $tax_id)->get('tbl_tax_rates')->row();
                    $total_tax += $tax_info->tax_rate_percent;
                }
            }
            if (!empty($tax_rates)) {
                $data['tax_rates_id'] = json_encode($tax_rates);
            } else {
                $data['tax_rates_id'] = '-';
            }

            $sub_total = $data['cost_per_month'];
            $data['item_tax_rate']  = ($total_tax / 100);
            $data['item_tax_total'] = $data['item_tax_rate'] * $sub_total;
            $data['total_cost']     = $sub_total + $data['item_tax_total'];
            
            // save into database
            $this->billboards_model->_table_name = 'tbl_billboards';
            $this->billboards_model->_primary_key = 'billboard_id';
            $return_id = $this->billboards_model->save($data, $id);

            // save_custom_field(18, $id);

            if (!empty($id)) {
                $id     = $id;
                $action = 'activity_update_billboard';
                $msg    = lang('update_billboard');
            } else {
                $id     = $return_id;
                $action = 'activity_save_billboard';
                $msg    = lang('save_billboard');
            }

            $activity = array(
                'user'      => $this->session->userdata('user_id'),
                'module'    => 'billboards',
                'module_field_id' => $id,
                'activity'  => $action,
                'icon'      => 'fa-circle-o',
                'value1'    => $data['billboard_name']
            );
            $this->billboards_model->_table_name = 'tbl_activities';
            $this->billboards_model->_primary_key = 'activities_id';
            $this->billboards_model->save($activity);
            // messages for user
            $type = "success";
        }
        $message = $msg;
        set_message($type, $message);
        redirect('admin/billboards');
    }

    public function delete($id, $bulk = null)
    {
        $can_delete_invoice = can_action('13', 'deleted');
        if (!empty($can_delete_invoice)) {
            $items_info = $this->billboards_model->check_by(array('billboard_id' => $id), 'tbl_billboards');
            $activity = array(
                'user'      => $this->session->userdata('user_id'),
                'module'    => 'billboards',
                'module_field_id' => $id,
                'activity'  => 'activity_billboard_deleted',
                'icon'      => 'fa-circle-o',
                'value1'    => $items_info->billboard_name
            );
            $this->billboards_model->_table_name = 'tbl_activities';
            $this->billboards_model->_primary_key = 'activities_id';
            $this->billboards_model->save($activity);

            $this->billboards_model->_table_name = 'tbl_billboards';
            $this->billboards_model->_primary_key = 'billboard_id';
            $this->billboards_model->delete($id);
            $type = 'success';
            $message = lang('delete_billboard');
        } else {
            $type = "error";
            $message = lang('no_permission');
        }
        if (!empty($bulk)) {
            return (array("status" => $type, 'message' => $message));
        }
        echo json_encode(array("status" => $type, 'message' => $message));
        exit();
    }

    public function bulk_delete()
    {
        $selected_id = $this->input->post('ids', true);
        if (!empty($selected_id)) {
            foreach ($selected_id as $id) {
                $result[] = $this->delete($id, true);
            }
            echo json_encode($result);
            exit();
        } else {
            $type = "error";
            $message = lang('you_need_select_to_delete');
            echo json_encode(array("status" => $type, 'message' => $message));
            exit();
        }
    }

    public function import()
    {
        $header         = lang('billboards');
        $data['title']  = lang('import') . ' ' . $header;
        $data['permission_user'] = $this->billboards_model->all_permission_user('30');
        $data['type']   = 'billboards';
        $data['subview'] = $this->load->view('import', $data, TRUE);
        $this->load->view('admin/_layout_main', $data); //page load
    }

    public function save_imported()
    {
        $this->load->library('excel');
        ob_start();
        $file = $_FILES["upload_file"]["tmp_name"];
        if (!empty($file)) {
            $valid = false;
            $types = array('Excel2007', 'Excel5', 'CSV');
            foreach ($types as $type) {
                $reader = PHPExcel_IOFactory::createReader($type);
                if ($reader->canRead($file)) {
                    $valid = true;
                }
            }
            if (!empty($valid)) {
                try {
                    $objPHPExcel = PHPExcel_IOFactory::load($file);
                } catch (Exception $e) {
                    die("Error loading file :" . $e->getMessage());
                }
                // All data from excel
                $sheetData = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);

                $all_data = array();
                for ($x = 2; $x <= count($sheetData); $x++) {
                    $data['billboard_name'] = trim($sheetData[$x]["A"]);
                    $data['description']    = trim($sheetData[$x]["B"]);
                    $data['location']       = trim($sheetData[$x]["C"]);
                    $data['city']           = trim($sheetData[$x]["D"]);
                    $data['region']         = trim($sheetData[$x]["E"]);
                    $data['country']        = trim($sheetData[$x]["F"]);
                    $data['latitude']       = trim($sheetData[$x]["G"]);
                    $data['longitude']      = trim($sheetData[$x]["H"]);
                    $data['faces']          = trim($sheetData[$x]["I"]);
                    $data['dimension']      = trim($sheetData[$x]["J"]);
                    $data['type']           = trim($sheetData[$x]["K"]);
                    $data['orientation']    = trim($sheetData[$x]["L"]);
                    $data['ownership']      = trim($sheetData[$x]["M"]);
                    $unit_cost              = str_replace(',', '', trim($sheetData[$x]["N"]));
                    $data['cost_per_month'] = preg_replace("/[^0-9,.]/", "", $unit_cost);
                    $data['unit_type']      = trim($sheetData[$x]["O"]);
                    $data['occupancy']      = trim($sheetData[$x]["P"]);
                    $data['status']         = trim($sheetData[$x]["Q"]);

                    $all_data[] = $data;
                }
                if (!empty($all_data)) {
                    $this->db->insert_batch('tbl_billboards', $all_data);
                }
                $type = 'success';
                $message = lang('imported_new_billboards');
                $redirect = 'items';
            } else {
                $type = 'error';
                $message = lang('file_type_error_xls');
            }
        } else {
            $type = 'error';
            $message = lang('no_file_selected_xls');
        }
        set_message($type, $message);
        redirect('admin/billboards');
    }

    // Global_controller
    /* Get billboard by id / ajax */
    public function get_billboard_by_id($id)
    // public function get_billboard_by_ajax($id)
    {
        if ($this->input->is_ajax_request()) {
            $billboard = $this->billboards_model->get_billboard_by_id($id);
            echo json_encode($billboard);
            exit();
        }
    }

    // Add new items to invoice, estimates or credit notes

    public function insert_billboards($module_id, $module = 'invoice')
    {
        if($module == 'estimates') {
            $edited = can_action('14', 'edited');
            $can_edit = $this->billboards_model->can_action('tbl_estimates', 'edit', array('estimates_id' => $module_id));
        } else {
            $edited = can_action('13', 'edited');
            $can_edit = $this->billboards_model->can_action('tbl_invoices', 'edit', array('invoices_id' => $module_id));
        }

        if (!empty($can_edit) && !empty($edited)) {
            $data['module']     = $module;
            $data['module_id']  = $module_id;

            $data['modal_subview'] = $this->load->view('_modal_insert_billboards', $data, FALSE);
            $this->load->view('admin/_layout_modal', $data);
        } else {
            set_message('error', lang('there_in_no_value'));
            redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function insert_billboard_items($module_id, $module = 'invoice')
    {
        if($module == 'estimates') {
            $can_edit = $this->billboards_model->can_action('tbl_estimates', 'edit', array('estimates_id' => $module_id));
            $edited = can_action('14', 'edited');
        } else {
            $edited = can_action('13', 'edited');
            $can_edit = $this->billboards_model->can_action('tbl_invoices', 'edit', array('invoices_id' => $module_id));
        }

        if (!empty($can_edit) && !empty($edited)) {
            $billboard_id = $this->input->post('billboard_id', TRUE);
            if (!empty($billboard_id)) {
                foreach ($billboard_id as $v_items_id) {
                    // reduce items by 1
                    // $this->billboards_model->reduce_items($v_items_id, 1);
                    // @todo: mark billboard as occupied

                    $items_info = $this->billboards_model->check_by(array('billboard_id' => $v_items_id), 'tbl_billboards');

                    $tax_info = json_decode($items_info->tax_rates_id);
                    $tax_name = array();
                    if (!empty($tax_info)) {
                        foreach ($tax_info as $v_tax) {
                            $all_tax = $this->db->where('tax_rates_id', $v_tax)->get('tbl_tax_rates')->row();
                            $tax_name[] = $all_tax->tax_rate_name . '|' . $all_tax->tax_rate_percent;
                        }
                    }
                    if (!empty($tax_name)) {
                        $tax_name = $tax_name;
                    } else {
                        $tax_name = array();
                    }

                    $data['quantity']   = 1;
                    if($module == 'estimates') {
                        $data['estimates_id'] = $module_id;
                    } else {
                        $data['invoices_id'] = $module_id;
                    }
                    $data['billboard_id']   = $items_info->billboard_id;
                    $data['item_name']      = $items_info->billboard_name;
                    // description
                    // $data['item_desc']      = $items_info->description;
                    $item_desc = $items_info->location.', '.$items_info->city."\n".
                                ucfirst($items_info->orientation)." (".$items_info->dimension.")\n".
                                ucfirst($items_info->type)." (".$items_info->faces." faces)";
                    $data['item_desc']      = $item_desc;
                    // $data['hsn_code']       = $items_info->hsn_code;
                    $data['unit_cost']      = $items_info->cost_per_month;
                    $data['unit']           = $items_info->unit_type;
                    $data['item_tax_rate']  = '0.00';
                    $data['item_tax_name']  = json_encode($tax_name);
                    $data['item_tax_total'] = $items_info->item_tax_total;
                    $data['total_cost']     = $items_info->cost_per_month;
                    // attach new items to invoice/estimate
                    if($module == 'estimates') {
                        $this->billboards_model->_table_name = 'tbl_estimate_items';
                        $this->billboards_model->_primary_key = 'estimate_items_id';
                    } else {
                        $this->billboards_model->_table_name = 'tbl_items';
                        $this->billboards_model->_primary_key = 'items_id';
                    }
                    $items_id = $this->billboards_model->save($data);

                    // save activity
                    $action = ($module == 'estimates') ? 'activity_estimates_items_added' : ('activity_invoice_items_added');

                    $activity = array(
                        'user'      => $this->session->userdata('user_id'),
                        'module'    => $module,
                        'module_field_id' => $items_id,
                        'activity'  => $action,
                        'icon'      => 'fa-circle-o',
                        'value1'    => $items_info->billboard_name
                    );
                    $this->billboards_model->_table_name = 'tbl_activities';
                    $this->billboards_model->_primary_key = 'activities_id';
                    $this->billboards_model->save($activity);
                }
                // update this invoice/estimate, with new item charge & taxes
                $this->update_billboard_items_tax($billboard_id, $module_id, $module);

                $type = "success";
                $msg = ($module == 'estimates') ? lang('estimate_item_save') : lang('invoice_item_added');
            } else {
                $type = "error";
                $msg = lang('no_item_selected');
            }
            $message = $msg;
            set_message($type, $message);
            if($module == 'estimates') {
                redirect('admin/estimates/index/estimates_details/' . $module_id);
            } else {
                redirect('admin/invoice/manage_invoice/invoice_details/' . $module_id);
            }
        } else {
            set_message('error', lang('there_in_no_value'));

            if (empty($_SERVER['HTTP_REFERER'])) {
                if($module == 'estimates') {
                    redirect('admin/estimates');
                } else {
                    redirect('admin/invoice/manage_invoice');
                }
            } else {
                redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }

    function update_billboard_items_tax($billboard_id, $module_id, $module = 'invoice')
    {
        // get the existing tax info for this module
        if($module == 'estimates') {
            $invoice_info = $this->billboards_model->check_by(array('estimates_id' => $module_id), 'tbl_estimates');
        } else {
            $invoice_info   = $this->billboards_model->check_by(array('invoices_id' => $module_id), 'tbl_invoices');
        }
        $tax_info       = json_decode($invoice_info->total_tax);

        $tax_name       = $tax_info->tax_name;
        $total_tax      = $tax_info->total_tax;
        $invoice_tax    = array();
        if (!empty($tax_name)) {
            foreach ($tax_name as $t_key => $v_tax_info) {
                array_push($invoice_tax, array('tax_name' => $v_tax_info, 'total_tax' => $total_tax[$t_key]));
            }
        }
        // get tax info from the new items added
        $all_tax_info = array();
        if (!empty($billboard_id)) {
            foreach ($billboard_id as $v_items_id) {
                // get tax rates and info for each item
                $items_info = $this->billboards_model->check_by(array('billboard_id' => $v_items_id), 'tbl_billboards');
                $tax_info = json_decode($items_info->tax_rates_id);
                if (!empty($tax_info)) {
                    foreach ($tax_info as $v_tax) {
                        $all_tax = $this->db->where('tax_rates_id', $v_tax)->get('tbl_tax_rates')->row();
                        // populate the tax info for the new items
                        array_push($all_tax_info, array('tax_name' => $all_tax->tax_rate_name . '|' . $all_tax->tax_rate_percent, 'total_tax' => ($items_info->unit_cost / 100) * $all_tax->tax_rate_percent));
                    }
                }
            }
        }
        // merge old with new tax info
        if (!empty($invoice_tax) && is_array($invoice_tax) && !empty($all_tax_info)) {
            $all_tax_info = array_merge($all_tax_info, $invoice_tax);
        }

        $results = array();
        foreach ($all_tax_info as $value) {
            if (!isset($results[$value['tax_name']])) {
                $results[$value['tax_name']] = 0;
            }
            $results[$value['tax_name']] += $value['total_tax'];
        }
        if (!empty($results)) {

            foreach ($results as $key => $value) {
                $structured_results['tax_name'][] = $key;
                $structured_results['total_tax'][] = $value;
            }
            $invoice_data['tax']        = array_sum($structured_results['total_tax']);
            $invoice_data['total_tax']  = json_encode($structured_results);

            if($module == 'estimates') {
                $this->billboards_model->_table_name = 'tbl_estimates';
                $this->billboards_model->_primary_key = 'estimates_id';
            } else {
                $this->billboards_model->_table_name = 'tbl_invoices';
                $this->billboards_model->_primary_key = 'invoices_id';
            }
            $this->billboards_model->save($invoice_data, $module_id);
        }
        return true;
    }

    public function occupancy($action = null, $id = NULL, $active = 1)
    {
        $data['title'] = lang('cash_request').' & '.lang('refund');
        $data['active'] = 1;
        $data['user_can_manage_invoices'] = $this->user_can_manage_invoices;

        // get all client
        $this->billboards_model->_table_name = 'tbl_client';
        $this->billboards_model->_order_by = 'client_id';
        $data['all_clients'] = $this->billboards_model->get();
        // skip vacant billboards
        $all_items          = $this->db->where('occupancy !=', 'vacant')->order_by('billboard_name', 'ASC')->get('tbl_billboards')->result();
        $data['all_items']  = $all_items;

        $all_users          = $this->db->where('role_id !=', 2)->get('tbl_users')->result(); // skip clients
        $data['all_users']  = $all_users;

        $all_request_category           = $this->db->get('tbl_cash_request_category')->result();
        $data['all_request_category']   = $all_request_category;

        if (!empty($id)) {
            $data['item_info'] = $this->billboards_model->check_by(array('billboard_id' => $id), 'tbl_billboards');
        }

        if ($action == 'apply') {
            $data['title']          = lang('billboard').' '.lang('occupancy');
            $data['dropzone']       = true;
            $data['user_can_manage_invoices'] = $this->user_can_manage_invoices;
            $data['modal_subview']  = $this->load->view('occupancy', $data, FALSE);
            $this->load->view('admin/_layout_modal', $data);
        } elseif ($action == 'view') {
            $data['title']      = lang('request') . ' ' . lang('details');
            $data['active']     = $active;
            $data['user_can_manage_invoices'] = $this->user_can_manage_invoices;
            $data['dropzone']   = true;
            $data['item_info']  = $this->billboards_model->check_by(array('billboard_id' => $id), 'tbl_billboards');
            // $data['modal_subview'] = $this->load->view('admin/transactions/cash_request/request_details', $data, FALSE);
            // $this->load->view('admin/_layout_modal', $data);
            $subview = 'request_details';
        } elseif ($action == 'edit') {
            $data['title']  = lang('edit') . ' ' . lang('cash_request_refund');
            $data['active'] = 2;
            $data['user_can_manage_invoices'] = $this->user_can_manage_invoices;
            $data['item_info']      = $this->billboards_model->check_by(array('billboard_id' => $id), 'tbl_billboards');
            $data['modal_subview']  = $this->load->view('occupancy', $data, FALSE);
        } else {
            $subview = 'details';
        }

        if (!in_array($action, ['apply', 'edit'])) {
            $data['subview'] = $this->load->view('admin/transactions/cash_request/' . $subview, $data, TRUE);
            $this->load->view('admin/_layout_main', $data); //page load
        }
    }

    public function update_occupancy($id = null)
    {
        $data = $this->billboards_model->array_from_post(array('billboard_id', 'project_id', 'start_date', 'expiry_date', 'period', 'status'));
        // check for non expired occupancy of this billboard
        $where = array('expiry_date >=' => $data['start_date']);
        // where id is not the one being edited
        if (!empty($id)) {
            $billboard_id = array('occupancy_id !=' => $id);
        // if id is not exist then set id as null
        } else {
            $billboard_id = null;
        }
        // check whether this input data already exist or not
        $check_items = $this->billboards_model->check_update('tbl_billboards_occupancy', $where, $billboard_id);
        // if input data already exist show error alert
        if (!empty($check_items)) {
            // massage for user
            $type = 'error';
            $msg = "<strong>".lang('sorry').'</strong>  ' . lang('billboard_occupied');
        } else { // save and update query          
            if (empty($data['start_date'])) {
                $data['start_date'] = date('Y-m-d H:i:s');
            }

            $data['date_updated'] = date('Y-m-d H:i:s');

            // save into database
            $this->billboards_model->_table_name = 'tbl_billboards_occupancy';
            $this->billboards_model->_primary_key = 'occupancy_id';
            $return_id = $this->billboards_model->save($data, $id);

            // update the corresponding billboard
            $item_info = $this->db->where('billboard_id', $data['billboard_id'])->get('tbl_billboards')->row();
            $_data['occupancy'] = (in_array($data['status'], array('started', 'in_progress'))) ? 'occupied' : 'vacant';

            $this->billboards_model->_table_name = 'tbl_billboards';
            $this->billboards_model->_primary_key = 'billboard_id';
            $this->billboards_model->save($_data, $data['billboard_id']);

            if (!empty($id)) {
                $id     = $id;
                $action = 'activity_update_billboard_occupancy';
                $msg    = lang('update_billboard');
            } else {
                $id     = $return_id;
                $action = 'activity_save_billboard_occupancy';
                $msg    = lang('save_billboard');
            }

            $activity = array(
                'user'      => $this->session->userdata('user_id'),
                'module'    => 'billboards',
                'module_field_id' => $data['billboard_id'],
                'activity'  => $action,
                'icon'      => 'fa-circle-o',
                'value1'    => $item_info->billboard_name
            );
            $this->billboards_model->_table_name = 'tbl_activities';
            $this->billboards_model->_primary_key = 'activities_id';
            $this->billboards_model->save($activity);
            // messages for user
            $type = "success";
        }
        $message = $msg;
        set_message($type, $message);
        redirect('admin/billboards');

    }

    public function inline_billboard()
    {
        $data['title'] = lang('new') . ' ' . lang('billboard');
        $data['user_can_manage_invoices'] = $this->user_can_manage_invoices;
        $data['modal_subview'] = $this->load->view('_modal_inline_billboard', $data, FALSE);
        $this->load->view('admin/_layout_modal', $data);
    }

    public function update_inline_billboard($id = null)
    {
        if($this->user_can_manage_invoices) {

            $this->application_model->_table_name = 'tbl_cash_request_category';
            $this->application_model->_primary_key = 'request_category_id';
            // input data
            $data = $this->application_model->array_from_post(array('request_category', 'description'));
            // dublicacy check
            if (!empty($id)) {
                $request_category_id = array('request_category_id !=' => $id);
            } else {
                $request_category_id = null;
            }
            // check check_request_category by where
            $where = array('request_category' => $data['request_category']);
            // if not empty show alert message else save data
            $check_request_category = $this->application_model->check_update('tbl_cash_request_category', $where, $request_category_id);
            // if input data already exist show error alert
            if (!empty($check_request_category)) {
                // massage for user
                $type = 'error';
                $msg = "<strong style='color:#000'>" . $data['request_category'] . '</strong>  ' . lang('already_exist');
            // save and update query
            } else {
                $id = $this->application_model->save($data);
                // save activity
                $activity = array(
                    'user'      => $this->session->userdata('user_id'),
                    'module'    => 'settings',
                    'module_field_id' => $id,
                    'activity'  => ('activity_added_a_request_category'),
                    'value1'    => $data['request_category']
                );
                $this->application_model->_table_name = 'tbl_activities';
                $this->application_model->_primary_key = 'activities_id';
                $this->application_model->save($activity);
                // messages for user
                $type = "success";
                $msg = lang('request_category_added');
            }
            if (!empty($id)) {
                $result = array(
                    'id'    => $id,
                    'name' => $data['request_category'],
                    'status' => $type,
                    'message' => $msg,
                );
            } else {
                $result = array(
                    'status' => $type,
                    'message' => $msg,
                );
            }
            echo json_encode($result);
            exit();
        }
    }

    function remove_numbers($string)
    {
        $string = preg_replace("/\([^)]+\)/", "", $string);
        $num = array('0.', '1.', '2.', '3.', '4.', '5.', '6.', '7.', '8.', '9.');
        return str_replace($num, '_', $string);
    }

    
    


}
