<?php include_once 'assets/admin-ajax.php'; ?>
<?php include_once 'asset/admin-ajax.php'; ?>
<?php
$currency = $this->billboards_model->check_by(array('code' => config_item('default_currency')), 'tbl_currencies');
?> 
<style type="text/css">
    #related_to .col-sm-5 {
        width: 66.66666667%;
    }
    @media screen and (max-width: 768px) {
        #related_to .col-sm-5 {
            width: 100%;
        }
    }
</style>

<div class="panel panel-custom">
    <div class="panel-heading">
        <button type="button" class="close" data-dismiss="modal">
            <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="myModalLabel"><?= $title; ?></h4>
    </div>
    <div class="modal-body wrap-modal wrap">
        <div class="row">
            <div class="col-sm-12">
                <form data-parsley-validate="" novalidate="" action="<?php echo base_url() ?>admin/billboards/update_occupancy/<?php
                    echo (isset($item_info->request_id)) ? $item_info->request_id : NULL;  ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                    <input type="hidden" id="user_id" value="<?php echo $this->session->userdata('user_id') ?>">
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label"><?= lang('billboard') ?>
                            <span class="required"> *</span>
                        </label>
                        <?php $saved_boards = $this->billboards_model->get_all_billboards(); ?>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <select name="billboard_id" class="form-control select_box" data-width="100%"
                                        id="billboard_id" required="true" style="width: 100%">
                                    <option value=""><?= lang('select'); ?></option>
                                    <?php
                                    if (!empty($saved_boards)) {
                                        $saved_boards = array_reverse($saved_boards, true);
                                        foreach ($saved_boards as $region => $v_saved_boards) { ?>
                                            <optgroup data-group-id="<?php echo $region; ?>"
                                                      label="<?php echo ucfirst($region); ?>">
                                                <?php
                                                if (!empty($v_saved_boards)) {
                                                    foreach ($v_saved_boards as $v_item) {
                                                        // skip occupied billboards
                                                        if ($v_item->occupancy != 'vacant') continue; ?>
                                                        <option value="<?php echo $v_item->billboard_id; ?>"
                                                                data-subtext="<?php echo $v_item->location.', '.$v_item->city; ?>">
                                                            <?php echo $v_item->billboard_name.' - '.$v_item->location.', '.$v_item->city; ?> (<?= display_money($v_item->cost_per_month, $currency->symbol); ?>
                                                            ) </option>
                                                    <?php }
                                                }
                                                ?>
                                            </optgroup>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                                <!-- <div class="input-group-addon" id="inline_billboard" title="<?= lang('new') . ' ' . lang('billboard') ?>" data-toggle="tooltip" data-placement="top">
                                    <a data-toggle="modal" data-target="#myModal" href="<?= base_url() ?>admin/billboards/inline_billboard"><i class="fa fa-plus"></i></a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                    <!-- <?php if (count($all_clients) > 0) { ?>
                        <?php foreach ($all_clients as $client) { ?>
                            <li class="filter_by" id="<?= $client->client_id ?>" search-type="by_client">
                                <a href="#"><?php echo $client->name; ?></a>
                            </li>
                        <?php } ?>
                        <div class="clearfix"></div>
                    <?php } ?> -->
                    <div class="form-group">
                        <label for="field-1" class="col-sm-3 control-label"><?= lang('project_') ?>
                            <span class="required"> *</span>
                        </label>

                        <div class="col-sm-8 ">
                            <div class="input-group">
                                <select name="project_id" style="width: 100%" class="form-control select_box" id="project_id" required="true">
                                    <option value=""><?= lang('select'); ?></option>
                                    <?php
                                    $all_project_info = $this->db->where_not_in('project_status', array('cancel', 'completed'))->order_by('project_name', 'ASC')->get('tbl_project')->result();
                                    if ($all_project_info) {
                                        foreach ($all_project_info as $v_project) {
                                            echo "<option value='" . $v_project->project_id . "'>" . $v_project->project_name . "</option>";
                                        }
                                    }
                                    ?>
                                </select>
                                <div class="input-group-addon" data-toggle="tooltip" data-placement="top">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?= lang('start').' '.lang('date') ?>
                            <span class="required"> *</span></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <input type="text" name="start_date" id="start_date" required="true" class="form-control datepicker" value="<?php echo (isset($item_info->start_date)) ? date('Y-m-d', strtotime($item_info->start_date)) : '';  ?>" data-format="dd-mm-yyyy" placeholder="YYYY-MM-DD" >
                                <div class="input-group-addon">
                                    <a href="#"><i class="fa fa-calendar"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?= lang('end').' '.lang('date') ?>
                            <span class="required"> *</span></label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <input type="text" name="expiry_date" id="expiry_date" required="true" class="form-control datepicker" value="<?php echo (isset($item_info->expiry_date)) ? date('Y-m-d', strtotime($item_info->expiry_date)) : '';  ?>" data-format="dd-mm-yyyy" placeholder="YYYY-MM-DD" >
                                <div class="input-group-addon">
                                    <a href="#"><i class="fa fa-calendar"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label"><?= lang('period') ?> 
                            <span class="text-danger">*</span>
                        </label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <input class="form-control" data-parsley-type="number" type="text"
                                       value="<?php
                                       if (!empty($item_info)) {
                                           echo $item_info->period;
                                       }
                                       ?>" name="period" required="true" placeholder="In months e.g. 1, 2, 3, 4, 6, 12" />
                                <div class="input-group-addon">
                                    <a href="#"><i class="fa fa-calendar"></i></a>
                                </div>
                            </div>
                            <span class="help-block"><i class="fa fa-info-circle text-info"></i> <small><?= lang('billboard_period_helper'); ?></small></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-3 control-label">
                            <?= lang('status') ?> <span class="text-danger">*</span>
                        </label>
                        <div class="col-lg-8">
                            <select name="status" class="form-control select_box" style="width: 100%" required="">
                                <option <?php
                                if (!empty($item_info->status)) {
                                    echo $item_info->status == 'pending' ? 'selected' : null;
                                } ?>
                                        value="pending"><?= lang('pending') ?></option>
                                <option <?php
                                if (!empty($item_info->status)) {
                                    echo $item_info->status == 'started' ? 'selected' : null;
                                } ?>
                                        value="started"><?= lang('started') ?></option>
                                <option <?php
                                if (!empty($item_info->status)) {
                                    echo $item_info->status == 'in_progress' ? 'selected' : null;
                                } ?>
                                        value="in_progress"><?= lang('in_progress') ?></option>
                                <option <?php
                                if (!empty($item_info->status)) {
                                    echo $item_info->status == 'on_hold' ? 'selected' : null;
                                } ?>
                                        value="on_hold"><?= lang('on_hold') ?></option>
                                <option <?php
                                if (!empty($item_info->status)) {
                                    echo $item_info->status == 'cancelled' ? 'selected' : null;
                                } ?>
                                        value="cancelled"><?= lang('cancelled') ?></option>
                                <option <?php
                                if (!empty($item_info->status)) {
                                    echo $item_info->status == 'completed' ? 'selected' : null;
                                } ?>
                                        value="completed"><?= lang('completed') ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group mt-lg">
                        <div class="col-sm-offset-3 col-sm-5">
                            <button type="submit" id="file-save-button" name="sbtn" value="1" class="btn btn-primary">Submit
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<script type="text/javascript">
    $('#myModal_extra_lg').on('hidden.bs.modal', function() {
        location.reload();
    });

    $(document).ready(function() {
        $("#inline_billboard").click(function() {
            $("#myModal").css("zIndex", '1052');
        });
        <?php if(isset($item_info->request_type) && $item_info->request_type == 1): ?>
            $('div#payment_month').show();
            $('#cash_refund_note').show();
        <?php else: ?>
            // $('div#request_attachment').hide();
            $('div#payment_month').hide();
            $('#cash_refund_note').hide();
        <?php endif; ?>

        $('input[name="request_type"]').click(function() {
            var request_type = this.value;
            if (request_type == '0') { // cash_request
                // $('div#request_attachment').hide().removeAttr('required');
                // $('input[name="files"]').removeAttr('required');
                $('div#payment_month').hide();
                $('#cash_refund_note').hide();
            } else if (request_type == '1') { // cash_refund
                // $('div#request_attachment').show().attr('required', true);
                // $('input[name="files"]').attr('required', true);
                $('div#payment_month').show();
                $('#cash_refund_note').show();
            } else {
                // $('div#request_attachment').hide().removeAttr('required');
                // $('input[name="files"]').removeAttr('required');
                $('div#payment_month').hide();
                $('#cash_refund_note').hide();
            }
        });
        $('#request_category').on('change', function() {
            // $('#start_date').val('');
            // $('#end_date').val('');
        });
        <?php if (!empty(admin_head())) { ?>
            $('#users_id').on('change', function() {
                // $('#start_date').val('');
                // $('#end_date').val('');
            });
        <?php } ?>
        
        $('.datepicker').datepicker({
            autoclose: true,
            format: "yyyy-mm-dd"
        });

    });
</script>