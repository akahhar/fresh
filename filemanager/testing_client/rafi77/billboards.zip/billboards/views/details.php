<?php
echo message_box('success');
echo message_box('error');

// $request_cate_info  = $this->db->where('request_category_id', $item_info->request_category_id)->get('tbl_cash_request_category')->row();
// $profile_info       = $this->db->where('user_id', $item_info->user_id)->get('tbl_account_details')->row();
// $approve_by         = $this->db->where('user_id', $item_info->approve_by)->get('tbl_account_details')->row();
// $request_type       = $item_info->request_type == 0 ? lang('cash_request') : lang('cash_refund');
// tab info
// $comment_details = $this->db->where(array('request_id' => $item_info->request_id, 'comments_reply_id' => '0', 'task_attachment_id' => '0', 'uploaded_files_id' => '0'))->order_by('comment_datetime', 'DESC')->get('tbl_task_comment')->result();
$activities_info = $this->db->where(array('module' => 'billboards', 'module_field_id' => $item_info->billboard_id))->order_by('activity_date', 'DESC')->get('tbl_activities')->result();

$comment_type = 'requests';

if ($item_info->occupancy == 'vacant') {
    $text = lang('vacant');
    $ribbon = 'warning';
} else {
    $text = lang('occupied');
    $ribbon = 'success';
}
?>
<div class="row mt-lg">
    <div class="col-sm-2">
        <ul class="nav nav-pills nav-stacked navbar-custom-nav">
            <li class="<?= $active == 1 ? 'active' : '' ?>">
                <a href="#details" data-toggle="tab"><?= lang('details') ?></a>
            </li>
            <!-- <li class="<?= $active == 2 ? 'active' : '' ?>">
                <a href="#occupancy" data-toggle="tab"><?= lang('occupancy') ?></a>
            </li>
            <li class="<?= $active == 3 ? 'active' : '' ?>"><a href="#comments" data-toggle="tab"><?= lang('comments') ?><strong class="pull-right"><?= (!empty($comment_details) ? count($comment_details) : null) ?></strong></a>
            </li> -->
            <li class="<?= $active == 4 ? 'active' : '' ?>" style="margin-right: 0px; "><a href="#activities" data-toggle="tab"><?= lang('activities') ?>
                    <strong class="pull-right"><?= (!empty($activities_info) ? count($activities_info) : null) ?></strong></a>
            </li>
        </ul>
    </div>
    <div class="col-sm-10">
        <div class="tab-content" style="border: 0;padding:0;">
            <!-- Request Details Tab -->
            <div class="tab-pane <?= $active == 1 ? 'active' : '' ?>" id="details" style="position: relative;">
                <div class="panel panel-custom" id="print_items">
                    <header class="panel-heading">
                        <!-- <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button> -->
                        <?= lang('billboard') . ' <strong>#'. $item_info->billboard_name .'</strong>';?>
                        &nbsp;&nbsp;&nbsp;
                        <div class="btn-group">
                            <a class="btn btn-primary btn-xs mr" href="<?= base_url('admin/billboards/index/' . $item_info->billboard_id) ?>" data-toggle="tooltip" data-placement="top" title="<?= lang('edit') ?>"><i class="fa fa-pencil-square-o"></i></a>
                            <button type="button" class="btn btn-danger btn-xs mr" data-toggle="tooltip" data-placement="top" title="<?= lang('print') ?>" onclick="print_items('print_items')">
                                <i class="fa fa-print"></i>
                            </button>
                        </div>
                        <div class="ribbon <?php if (!empty($ribbon)) { echo $ribbon; } else { echo 'primary'; } ?>"><span><?= $text; ?></span></div>
                    </header>

                    <div class="modal-body">
                        <?php
                        $currency = $this->db->where('code', config_item('default_currency'))->get('tbl_currencies')->row();
                        ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="table-responsive">
                                    <table class="table table-striped ">
                                        <tbody>
                                            <tr>
                                                <td class="col-xs-4 text-right"><strong><?= lang('billboard_name') ?> : </strong></td>
                                                <td class="col-xs-8"><?= $item_info->billboard_name ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('occupancy') ?> : </strong></td>
                                                <td class="<?php if($item_info->occupancy == 'occupied') { echo 'text-success'; } else { echo 'text-warning'; } ?>">
                                                    <?= ucfirst($item_info->occupancy); ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('location') ?> : </strong></td>
                                                <td><?= $item_info->location ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('city') ?> : </strong></td>
                                                <td><?= $item_info->city ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('region') ?> : </strong></td>
                                                <td><?= $item_info->region; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('country') ?> : </strong></td>
                                                <td><?= $item_info->country; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('latitude') ?> : </strong></td>
                                                <td><?= $item_info->latitude; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('longitude') ?> : </strong></td>
                                                <td><?= $item_info->longitude; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('type') ?> : </strong></td>
                                                <td><?= $item_info->type; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('dimension') ?> : </strong></td>
                                                <td><?= $item_info->dimension; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('faces') ?> : </strong></td>
                                                <td><?= $item_info->faces; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('orientation') ?> : </strong></td>
                                                <td><?= $item_info->orientation; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('ownership') ?> : </strong></td>
                                                <td><?= $item_info->ownership; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('cost_per_month') ?> : </strong></td>
                                                <td><?= display_money($item_info->cost_per_month, $currency->symbol); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('charge') . ' ' . lang('type') ?> : </strong></td>
                                                <td><?= $item_info->unit_type; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-right"><strong><?= lang('tax') ?> : </strong></td>
                                                <td>
                                                    <?php
                                                    if (!is_numeric($item_info->tax_rates_id)) {
                                                        $tax_rates = json_decode($item_info->tax_rates_id);
                                                    } else {
                                                        $tax_rates = null;
                                                    }
                                                    if (!empty($tax_rates)) {
                                                        foreach ($tax_rates as $key => $tax_id) {
                                                            $taxes_info = $this->db->where('tax_rates_id', $tax_id)->get('tbl_tax_rates')->row();
                                                            if (!empty($taxes_info)) {
                                                                echo $key + 1 . '. ' . $taxes_info->tax_rate_name . '&nbsp;&nbsp; (' . $taxes_info->tax_rate_percent . '% ) <br>';
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <?php if (!empty($item_info->description)) { ?>
                                <div class="col-xs-12 mt-lg">
                                    <div class="panel panel-custom">
                                        <div class="panel-heading"><?= lang('description') ?></div>
                                        <div class="panel-body">
                                            <?= strip_html_tags($item_info->description) ?>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                            </div>
                            <div class="col-md-6">
                                <!-- Google Map Starts -->
                                <script src="https://maps.google.com/maps/api/js?key=<?= config_item('google_api_key'); ?>" type="text/javascript"></script>
                                
                                <div id="gmap_canvas" style="width: 100%; height: 600px;"></div>

                                <script type="text/javascript">
                                    // add generated coordinates to var locations
                                    var Latlng = new google.maps.LatLng(<?= $item_info->latitude.', '.$item_info->longitude; ?>);
                                    var options = {
                                        zoom: 15,
                                        center: Latlng,
                                        mapTypeId: google.maps.MapTypeId.ROADMAP
                                    }

                                    var map = new google.maps.Map(document.getElementById("gmap_canvas"), options);

                                    var contentString = '<div class="map-infowindow">'+
                                        '<div class="map-image-frame">'+
                                            '<img alt="<?= $item_info->billboard_name; ?>" src="" title="<?= $item_info->billboard_name; ?>" />'+
                                        '</div>'+
                                        '<div class="map-content">'+
                                            '<span class="map-title"><?= $item_info->billboard_name; ?></span><br />'+
                                            '<span class="map-occupancy"><?= $item_info->occupancy; ?></span>'+
                                        '</div>'+
                                        '<div class="map-pricing-frame">'+
                                            '<strong><?= display_money($item_info->cost_per_month, $currency->symbol); ?></strong> /<?= $item_info->unit_type; ?><br />'+
                                            '<div class="view-link"> <a target="_blank" href="https://maps.google.com/maps?ll=<?= $item_info->latitude.','.$item_info->longitude; ?>&amp;z='+options.zoom+'&amp;t=m&amp;hl=en-US&amp;gl=US&amp;mapclient=apiv3" tabindex="0"><span>View on Google Maps</span></a></div>'+
                                        '</div>'+
                                        '</div>';

                                    var infowindow = new google.maps.InfoWindow({
                                        content: contentString
                                    });

                                    var marker = new google.maps.Marker({
                                        position: Latlng,
                                        map: map,
                                        title: "<?= $item_info->billboard_name; ?>"
                                    });

                                    google.maps.event.addListener(marker, 'click', function() {
                                        infowindow.open(map,marker);
                                    });
                                    // open info window by default
                                    infowindow.open(map, marker);

                                </script>
                            <!-- Google Map Ends -->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- occupancy -->
            <div class="tab-pane <?= $active == 2 ? 'active' : '' ?>" id="occupancy" style="position: relative;">
            </div>
            <!-- Comments Tab -->
            <div class="tab-pane <?= $active == 2 ? 'active' : '' ?>" id="comments" style="position: relative;">
                
            </div>

            <!-- Activities Tab -->
            <div class="tab-pane <?= $active == 3 ? 'active' : '' ?>" id="activities" style="position: relative;">
                <div class="panel panel-custom">
                    <div class="panel-heading">
                        <h3 class="panel-title"><?= lang('activities') ?>
                            <?php
                            $role = $this->session->userdata('user_type');
                            if ($role == 1) {
                                ?>
                                <span class="btn btn-primary btn-xs pull-right">
                                    <i class="fa fa-ban"></i>&nbsp;
                                    <a href="<?= base_url() ?>admin/tasks/claer_activities/billboards/<?= $item_info->billboard_id ?>" class="text-white"><?= lang('clear') . ' ' . lang('activities') ?></a>
                                </span>
                            <?php } ?>
                        </h3>
                    </div>
                    <div class="panel-body " id="chat-box">
                        <?php
                        if (!empty($activities_info)) {
                            foreach ($activities_info as $v_activities) {
                                $profile_info = $this->db->where(array('user_id' => $v_activities->user))->get('tbl_account_details')->row();
                                $user_info = $this->db->where(array('user_id' => $v_activities->user))->get('tbl_users')->row();
                                ?>
                                <div class="timeline-2">
                                    <div class="time-item">
                                        <div class="item-info">
                                            <small data-toggle="tooltip" data-placement="top" title="<?= display_datetime($v_activities->activity_date) ?>" class="text-muted"><?= time_ago($v_activities->activity_date); ?></small>

                                            <p><strong>
                                                    <?php if (!empty($profile_info)) {
                                                    ?>
                                                        <a href="<?= base_url() ?>admin/user/user_details/<?= $profile_info->user_id ?>" class="text-info"><?= $profile_info->fullname ?></a>
                                                    <?php } ?>
                                                </strong> <?= sprintf(lang($v_activities->activity)) ?>
                                                <strong><?= $v_activities->value1 ?></strong>
                                                <?php if (!empty($v_activities->value2)) { ?>
                                            <p class="m0 p0"><strong><?= $v_activities->value2 ?></strong></p>
                                        <?php } ?>
                                        </p>
                                        </div>
                                    </div>
                                </div>
                        <?php
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- JQUERY-->
<!-- <script src="<?= base_url() ?>assets/js/jquery.min.js"></script> -->
<!-- <script type="text/javascript" src="<?= base_url().'modules/'.BILLBOARDS_MODULE; ?>/assets/plugins/jquery/tools/jquery.tools.min.js"></script> -->
<!-- <script type="text/javascript" src="<?= base_url().'modules/'.BILLBOARDS_MODULE; ?>/assets/plugins/jquery/transitions/jquery.transitions.js"></script> -->
<script type="text/javascript">
    function print_items(print_items) {
        var printContents = document.getElementById(print_items).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }
</script>