<!-- Google Map Code -->
<!-- <script async defer src="https://maps.googleapis.com/maps/api/js?key=<?= config_item('google_api_key'); ?>"></script> -->
<script src="https://maps.google.com/maps/api/js?key=<?= config_item('google_api_key'); ?>" type="text/javascript"></script>

<?= message_box('success'); ?>
<?= message_box('error');
$created = can_action('39', 'created');
$edited = can_action('39', 'edited');
$deleted = can_action('39', 'deleted');

if (!empty($created) || !empty($edited)) {
?>
    <div class="nav-tabs-custom">
        <?php $is_department_head = is_department_head();
        if ($this->session->userdata('user_type') == 1 || !empty($is_department_head)) { ?>
            <div class="btn-group pull-right btn-with-tooltip-group _filter_data filtered" data-toggle="tooltip" data-title="<?php echo lang('filter_by'); ?>">
                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-filter" aria-hidden="true"></i>
                </button>
                <ul class="dropdown-menu group animated zoomIn" style="width:300px;">
                    <li class="filter_by all_filter"><a href="#"><?php echo lang('all'); ?></a></li>
                    <li class="divider"></li>
                    <li class="dropdown-submenu pull-left " id="to_occupancy">
                        <a href="#" tabindex="-1"><?php echo lang('by') . ' ' . lang('occupancy'); ?></a>
                        <ul class="dropdown-menu dropdown-menu-left to_occupancy">
                            <li class="filter_by" id="occupied" search-type="by_occupancy">
                                <a href="#"><?php echo lang('occupied'); ?></a>
                            </li>
                            <div class="clearfix"></div>
                            <li class="filter_by" id="vacant" search-type="by_occupancy">
                                <a href="#"><?php echo lang('vacant'); ?></a>
                            </li>
                            <div class="clearfix"></div>
                        </ul>
                    </li>
                    <div class="clearfix"></div>
                    <li class="dropdown-submenu pull-left " id="to_location">
                        <a href="#" tabindex="-1"><?php echo lang('by') . ' ' . lang('location'); ?></a>
                        <?php 
                            $saved_boards = $this->billboards_model->get_all_billboards();
                            $_locations = [];
                        ?>
                        <?php
                        if (!empty($saved_boards)) {
                            $saved_boards = array_reverse($saved_boards, true);
                            foreach ($saved_boards as $region => $v_saved_boards) {
                                if (!empty($v_saved_boards)) {
                                    foreach ($v_saved_boards as $v_item) {
                                        // get unique city
                                        $_locations[] = $v_item->city;
                                        $_locations = array_unique($_locations);
                                    }
                                }
                            }
                        }
                        ?>
                        <ul class="dropdown-menu dropdown-menu-left to_location">
                            <?php if (count($_locations) > 0) { ?>
                                <?php foreach ($_locations as $city) { ?>
                                    <li class="filter_by" id="<?= $city; ?>" search-type="by_location">
                                        <a href="#"><?php echo ucfirst($city); ?></a>
                                    </li>
                                <?php } ?>
                                <div class="clearfix"></div>
                            <?php } ?>
                        </ul>
                    </li>
                    <div class="clearfix"></div>
                    <!-- <li class="dropdown-submenu pull-left  " id="from_client">
                        <a href="#" tabindex="-1"><?php echo lang('by') . ' ' . lang('client'); ?></a>
                        <ul class="dropdown-menu dropdown-menu-left from_client">
                            <?php if (count($all_clients) > 0) { ?>
                                <?php foreach ($all_clients as $client) { ?>
                                    <li class="filter_by" id="<?= $client->client_id ?>" search-type="by_client">
                                        <a href="#"><?php echo $client->name; ?></a>
                                    </li>
                                <?php } ?>
                                <div class="clearfix"></div>
                            <?php } ?>
                        </ul>
                    </li> -->
                </ul>
            </div>
        <?php } ?>
        <!-- Tabs within a box -->
        <ul class="nav nav-tabs">
            <li class="<?= $active == 1 ? 'active' : ''; ?>"><a href="#manage" data-toggle="tab"><?= lang('all_billboards') ?></a></li>
            <li class="<?= $active == 2 ? 'active' : ''; ?>"><a href="#create" data-toggle="tab"><?= lang('new_billboard') ?></a></li>
            <li class="<?= $active == 3 ? 'active' : ''; ?>"><a href="#board_map" data-toggle="tab"><?= lang('billboard') . ' ' . lang('map') ?></a>
            </li>
            <li><a class="import" href="<?= base_url() ?>admin/billboards/import"><?= lang('import') . ' ' . lang('billboards') ?></a>
            </li>
            <li class="pull-right">
                <a href="<?= base_url() ?>admin/billboards/occupancy/apply"
                   class="bg-info"
                   data-toggle="modal" data-placement="top" data-target="#myModal_extra_lg">
                    <i class="fa fa-plus "></i> <?= lang('billboard') . ' ' . lang('occupancy'); ?>
                </a>
            </li>
        </ul>
        <style type="text/css">
            .custom-bulk-button {
                display: initial;
            }
        </style>
        <div class="tab-content bg-white">
            <!-- ************** general *************-->
            <div class="tab-pane <?= $active == 1 ? 'active' : ''; ?>" id="manage">
            <?php } else { ?>
                <div class="panel panel-custom">
                    <header class="panel-heading ">
                        <div class="panel-title"><strong><?= lang('all_billboards') ?></strong></div>
                    </header>
                <?php } ?>
                    <div class="table-responsive">
                        <table class="table table-striped DataTables bulk_table" id="DataTables" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <?php if (!empty($deleted)) { ?>
                                        <th data-orderable="false">
                                            <div class="checkbox c-checkbox">
                                                <label class="needsclick">
                                                    <input id="select_all" type="checkbox">
                                                    <span class="fa fa-check"></span></label>
                                            </div>
                                        </th>
                                    <?php } ?>
                                    <th><?= lang('name') ?></th>
                                    <th class=""><?= lang('location') ?></th>
                                    <th class=""><?= lang('city') ?></th>
                                    <th class=""><?= lang('region') ?></th>
                                    <th class=""><?= lang('type') ?></th>
                                    <th class=""><?= lang('dimension') ?></th>
                                    <th class=""><?= lang('ownership') ?></th>
                                    <th class=""><?= lang('charge') ?></th>
                                    <th class=""><?= lang('occupancy') ?></th>
                                    <?php if (!empty($edited) || !empty($deleted)) { ?>
                                        <th class=""><?= lang('action') ?></th>
                                    <?php } ?>
                                </tr>
                            </thead>
                            <tbody>
                                <script type="text/javascript">
                                    $(document).ready(function() {
                                        list = base_url + "admin/billboards/BillboardsList";
                                        bulk_url = base_url + "admin/billboards/bulk_delete";
                                        $('.filtered > .dropdown-toggle').on('click', function() {
                                            if ($('.group').css('display') == 'block') {
                                                $('.group').css('display', 'none');
                                            } else {
                                                $('.group').css('display', 'block')
                                            }
                                        });
                                        $('.filter_by').on('click', function() {
                                            $('.filter_by').removeClass('active');
                                            $('.group').css('display', 'block');
                                            $(this).addClass('active');
                                            var filter_by = $(this).attr('id');
                                            if (filter_by) {
                                                filter_by = filter_by;
                                            } else {
                                                filter_by = '';
                                            }
                                            var search_type = $(this).attr('search-type');
                                            if (search_type) {
                                                search_type = '/' + search_type;
                                            } else {
                                                search_type = '';
                                            }
                                            table_url(base_url + "admin/billboards/BillboardsList/" + filter_by + search_type);
                                        });
                                    });
                                </script>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if (!empty($created) || !empty($edited)) { ?>
                    <div class="tab-pane <?= $active == 2 ? 'active' : ''; ?>" id="create">
                        <form role="form" data-parsley-validate="" novalidate="" enctype="multipart/form-data" id="form" action="<?php echo base_url(); ?>admin/billboards/save/<?php if (!empty($items_info)) { echo $items_info->billboard_id; } ?>" method="post" class="form-horizontal row ">
                            <div class="col-md-7">
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('billboard_name') ?> <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" value="<?php if (!empty($items_info)) { echo $items_info->billboard_name; } ?>" name="billboard_name" required="true" placeholder="Unique board name" />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('type') ?> <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <?php
                                        if (!empty($items_info->type)) {
                                            $type = $items_info->type;
                                        } else {
                                            $type = null;
                                        }
                                        $b_type = array('unipole' => 'Unipole', 'wall_scape' => 'Wall Scape');
                                        echo form_dropdown('type', $b_type, set_value('type', $type), 'class="form-control select2" id="type" required="required" style="width:100%;"');
                                        ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('dimension') ?> <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <?php
                                        if (!empty($items_info->dimension)) {
                                            $dimension = $items_info->dimension;
                                        } else {
                                            $dimension = null;
                                        }
                                        $b_dimensions = array('6Mx9M' => '6M x 9M', '7Mx10M' => '7M x 10M', '8Mx10M' => '8M x 10M', '9Mx8M' => '9M x 8M', '9.6Mx9.6M' => '9.6M x 9.6M');
                                        echo form_dropdown('dimension', $b_dimensions, set_value('dimension', $dimension), 'class="form-control select2" id="dimension" required="required" style="width:100%;"');
                                        ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('faces') ?> <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <?php
                                        if (!empty($items_info->faces)) {
                                            $faces = $items_info->faces;
                                        } else {
                                            $faces = null;
                                        }
                                        $b_faces = array('1' => '1', '2' => '2', '3' => '3', '4' => '4');
                                        echo form_dropdown('faces', $b_faces, set_value('faces', $faces), 'class="form-control select2" id="faces" required="required" style="width:100%;"');
                                        ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('orientation') ?> <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <?php
                                        if (!empty($items_info->orientation)) {
                                            $orientation = $items_info->orientation;
                                        } else {
                                            $orientation = null;
                                        }
                                        $b_orientation = array('portrait' => 'Portrait', 'landscape' => 'Landscape');
                                        echo form_dropdown('orientation', $b_orientation, set_value('orientation', $orientation), 'class="form-control select2" id="orientation" required="required" style="width:100%;"');
                                        ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('ownership') ?> <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <?php
                                        if (!empty($items_info->ownership)) {
                                            $ownership = $items_info->ownership;
                                        } else {
                                            $ownership = null;
                                        }
                                        $b_ownership = array('owned' => 'Owned', 'leased' => 'Leased');
                                        echo form_dropdown('ownership', $b_ownership, set_value('ownership', $ownership), 'class="form-control select2" id="ownership" required="required" style="width:100%;"');
                                        ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">
                                        <?= lang('charge').' '.lang('fee') ?> <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-md-9">
                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <?= default_currency(); ?>
                                            </div>
                                            <input class="form-control" data-parsley-type="number" type="text"
                                                   value="<?php
                                                   if (!empty($items_info)) {
                                                       echo $items_info->cost_per_month;
                                                   }
                                                   ?>" name="cost_per_month" required="true" placeholder="5000" <?php
                                            if (!empty($items_info)) {
                                                // echo 'disabled';
                                            }
                                            ?>>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('charge') . ' ' . lang('type') ?>  <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" value="<?php if (!empty($items_info)) { echo $items_info->unit_type; } ?>" placeholder="<?= lang('billboard_unit_type_example') ?>" name="unit_type" required="true">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('tax') ?></label>
                                    <div class="col-md-9">
                                        <?php
                                        $taxes = $this->db->order_by('tax_rate_percent', 'ASC')->get('tbl_tax_rates')->result();
                                        if (!empty($items_info->tax_rates_id) && !is_numeric($items_info->tax_rates_id)) {
                                            $tax_rates_id = json_decode($items_info->tax_rates_id);
                                        }
                                        $select = '<select class="selectpicker" data-width="100%" name="tax_rates_id[]" multiple data-none-selected-text="' . lang('no_tax') . '">';
                                        foreach ($taxes as $tax) {
                                            $selected = '';
                                            if (!empty($tax_rates_id) && is_array($tax_rates_id)) {
                                                if (in_array($tax->tax_rates_id, $tax_rates_id)) {
                                                    $selected = ' selected ';
                                                }
                                            }
                                            $select .= '<option value="' . $tax->tax_rates_id . '"' . $selected . 'data-taxrate="' . $tax->tax_rate_percent . '" data-taxname="' . $tax->tax_rate_name . '" data-subtext="' . $tax->tax_rate_name . '">' . $tax->tax_rate_percent . '%</option>';
                                        }
                                        $select .= '</select>';
                                        echo $select;
                                        ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('location') ?> <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" value="<?php if (!empty($items_info)) { echo $items_info->location; } ?>" name="location" required="" placeholder="<?= lang('location_help') ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('city') ?>  <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" value="<?php
                                        if (!empty($items_info->city)) {
                                            echo $items_info->city;
                                        }
                                        ?>" name="city" required="true">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('region') ?> <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <?php
                                        if (!empty($items_info->region)) {
                                            $region = $items_info->region;
                                        } else {
                                            $region = null;
                                        }
                                        $b_region = array('central' => 'Central', 'eastern' => 'Eastern', 'northern' => 'Northern', 'western' => 'Western');
                                        echo form_dropdown('region', $b_region, set_value('region', $region), 'class="form-control select2" id="region" required="required" style="width:100%;"');
                                        ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?= lang('country') ?>  <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <select name="country" required="true" class="form-control select_box"
                                                style="width: 100%">
                                            <optgroup label="Default Country">
                                                <option value="<?= $this->config->item('company_country') ?>">
                                                    <?= $this->config->item('company_country') ?>
                                                </option>
                                            </optgroup>
                                            <optgroup label="<?= lang('other_countries') ?>">
                                                <?php if (!empty($countries)): foreach ($countries as $country): ?>
                                                    <option value="<?= $country->value ?>" <?= (!empty($items_info->country) && $items_info->country == $country->value ? 'selected' : NULL) ?>><?= $country->value ?>
                                                    </option>
                                                <?php
                                                endforeach;
                                                endif;
                                                ?>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">
                                        <a href="#"
                                           onclick="fetch_lat_long_from_google_maps(); return false;"
                                           data-toggle="tooltip"
                                           data-title="<?php echo lang('fetch_from_google') . ' - ' . lang('customer_fetch_lat_lng_usage'); ?>"><i
                                                    id="gmaps-search-icon" class="fa fa-google"
                                                    aria-hidden="true"></i></a>
                                        <?= lang('latitude') . '( ' . lang('google_map') . ' )' ?> <span class="text-danger">*</span>
                                    </label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" value="<?php
                                        if (!empty($items_info->latitude)) {
                                            echo $items_info->latitude;
                                        }
                                        ?>" name="latitude" required="true">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label
                                            class="col-md-3 control-label"><?= lang('longitude') . '( ' . lang('google_map') . ' )' ?> <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control"
                                               value="<?php
                                               if (!empty($items_info->longitude)) {
                                                   echo $items_info->longitude;
                                               }
                                               ?>" name="longitude" required="true">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="field-1" class="col-md-3 control-label"><?= lang('status') ?></label>
                                    <div class="col-md-9">
                                        <select class="form-control select_box" style="width: 100%" name="status">
                                            <option value="1"><?= lang('active') ?></option>
                                            <option value="0"><?= lang('inactive') ?></option>
                                        </select>
                                    </div>
                                </div>
                                <?php
                                if (!empty($items_info)) {
                                    $billboard_id = $items_info->billboard_id;
                                } else {
                                    $billboard_id = null;
                                }
                                ?>
                                <?= custom_form_Fields(18, $billboard_id); ?>

                                <div class="form-group mt-lg">
                                    <label class="col-md-3 control-label"></label>
                                    <div class="col-md-9">
                                        <div class="btn-bottom-toolbar">
                                            <?php if (!empty($items_info)) { ?>
                                                <button type="submit" class="btn btn-sm btn-primary"><?= lang('update') ?></button>
                                                <button type="button" onclick="goBack()" class="btn btn-sm btn-danger"><?= lang('cancel') ?></button>
                                            <?php } else { ?>
                                                <button type="submit" class="btn btn-sm btn-primary"><?= lang('save') ?></button>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="panel panel-custom">
                                    <div class="panel-heading">
                                        <?= lang('image') ?> </div>
                                    <div class="panel-body">
                                        <div id="comments_file-dropzone" class="dropzone mb15">

                                        </div>
                                        <div id="comments_file-dropzone-scrollbar">
                                            <div id="comments_file-previews">
                                                <div id="file-upload-row" class="mt pull-left">
                                                    <div class="preview box-content pr-lg" style="width:100px;">
                                                        <span data-dz-remove class="pull-right" style="cursor: pointer">
                                                            <i class="fa fa-times"></i>
                                                        </span>
                                                        <img data-dz-thumbnail class="upload-thumbnail-sm" />
                                                        <input class="file-count-field" type="hidden" name="files[]" value="" />
                                                        <div class="mb progress progress-striped upload-progress-sm active mt-sm" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                                                            <div class="progress-bar progress-bar-success" style="width:0%;" data-dz-uploadprogress></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        if (!empty($items_info->upload_file)) {
                                            $uploaded_file = json_decode($items_info->upload_file);
                                        }
                                        if (!empty($uploaded_file)) {
                                            foreach ($uploaded_file as $v_files_image) { ?>
                                                <div class="pull-left mt pr-lg mb" style="width:100px;">
                                                    <span data-dz-remove class="pull-right existing_image" style="cursor: pointer"><i class="fa fa-times"></i></span>
                                                    <?php if ($v_files_image->is_image == 1) { ?>
                                                        <img data-dz-thumbnail src="<?php echo base_url() . $v_files_image->path ?>" class="upload-thumbnail-sm" />
                                                    <?php } else { ?>
                                                        <span data-toggle="tooltip" data-placement="top" title="<?= $v_files_image->fileName ?>" class="mailbox-attachment-icon"><i class="fa fa-file-text-o"></i></span>
                                                    <?php } ?>

                                                    <input type="hidden" name="path[]" value="<?php echo $v_files_image->path ?>">
                                                    <input type="hidden" name="fileName[]" value="<?php echo $v_files_image->fileName ?>">
                                                    <input type="hidden" name="fullPath[]" value="<?php echo $v_files_image->fullPath ?>">
                                                    <input type="hidden" name="size[]" value="<?php echo $v_files_image->size ?>">
                                                    <input type="hidden" name="is_image[]" value="<?php echo $v_files_image->is_image ?>">
                                                </div>
                                            <?php }; ?>
                                        <?php }; ?>
                                        <script type="text/javascript">
                                            $(document).ready(function() {
                                                $(".existing_image").on("click", function() {
                                                    $(this).parent().remove();
                                                });

                                                fileSerial = 0;
                                                // Get the template HTML and remove it from the doumenthe template HTML and remove it from the doument
                                                var previewNode = document.querySelector("#file-upload-row");
                                                previewNode.id = "";
                                                var previewTemplate = previewNode.parentNode.innerHTML;
                                                previewNode.parentNode.removeChild(previewNode);
                                                Dropzone.autoDiscover = false;
                                                var projectFilesDropzone = new Dropzone("#comments_file-dropzone", {
                                                    url: "<?= base_url() ?>admin/global_controller/upload_file",
                                                    thumbnailWidth: 80,
                                                    thumbnailHeight: 80,
                                                    parallelUploads: 20,
                                                    previewTemplate: previewTemplate,
                                                    dictDefaultMessage: '<?php echo lang("file_upload_instruction"); ?>',
                                                    autoQueue: true,
                                                    previewsContainer: "#comments_file-previews",
                                                    clickable: true,
                                                    accept: function(file, done) {
                                                        if (file.name.length > 200) {
                                                            done("Filename is too long.");
                                                            $(file.previewTemplate).find(".description-field").remove();
                                                        }
                                                        // validate the file
                                                        $.ajax({
                                                            url: "<?= base_url() ?>admin/global_controller/validate_project_file",
                                                            data: {
                                                                file_name: file.name,
                                                                file_size: file.size
                                                            },
                                                            cache: false,
                                                            type: 'POST',
                                                            dataType: "json",
                                                            success: function(response) {
                                                                if (response.success) {
                                                                    fileSerial++;
                                                                    $(file.previewTemplate).find(".description-field").attr("name", "comment_" + fileSerial);
                                                                    $(file.previewTemplate).append("<input type='hidden' name='file_name_" + fileSerial + "' value='" + file.name + "' />\n\
                                                                        <input type='hidden' name='file_size_" + fileSerial + "' value='" + file.size + "' />");
                                                                    $(file.previewTemplate).find(".file-count-field").val(fileSerial);
                                                                    done();
                                                                } else {
                                                                    $(file.previewTemplate).find("input").remove();
                                                                    done(response.message);
                                                                }
                                                            }
                                                        });
                                                    },
                                                    processing: function() {
                                                        $("#file-save-button").prop("disabled", true);
                                                    },
                                                    queuecomplete: function() {
                                                        $("#file-save-button").prop("disabled", false);
                                                    },
                                                    fallback: function() {
                                                        //add custom fallback;
                                                        $("body").addClass("dropzone-disabled");
                                                        $('.modal-dialog').find('[type="submit"]').removeAttr('disabled');

                                                        $("#comments_file-dropzone").hide();

                                                        $("#file-modal-footer").prepend("<button id='add-more-file-button' type='button' class='btn  btn-default pull-left'><i class='fa fa-plus-circle'></i> " + "<?php echo lang("add_more"); ?>" + "</button>");

                                                        $("#file-modal-footer").on("click", "#add-more-file-button", function() {
                                                            var newFileRow = "<div class='file-row pb pt10 b-b mb10'>" +
                                                                "<div class='pb clearfix '><button type='button' class='btn btn-xs btn-danger pull-left mr remove-file'><i class='fa fa-times'></i></button> <input class='pull-left' type='file' name='manualFiles[]' /></div>" +
                                                                "<div class='mb5 pb5'><input class='form-control description-field'  name='comment[]'  type='text' style='cursor: auto;' placeholder='<?php echo lang("comment") ?>' /></div>" +
                                                                "</div>";
                                                            $("#comments_file-previews").prepend(newFileRow);
                                                        });
                                                        $("#add-more-file-button").trigger("click");
                                                        $("#comments_file-previews").on("click", ".remove-file", function() {
                                                            $(this).closest(".file-row").remove();
                                                        });
                                                    },
                                                    success: function(file) {
                                                        setTimeout(function() {
                                                            $(file.previewElement).find(".progress-striped").removeClass("progress-striped").addClass("progress-bar-success");
                                                        }, 1000);
                                                    }
                                                });

                                            })
                                        </script>
                                    </div>
                                </div>
                                <div class="">
                                    <label class=""><?= lang('description') ?> </label>
                                    <div class="">
                                        <textarea name="description" class="form-control textarea_"><?php if (!empty($items_info)) { echo $items_info->description; } ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane <?= $active == 3 ? 'active' : ''; ?> row" id="board_map">
                        <?php
                        $currency = $this->db->where('code', config_item('default_currency'))->get('tbl_currencies')->row();
                        $all_items = $this->db->where('status', 1)->get('tbl_billboards')->result();
                        ?>
                        <div class="col-md-4">  
                            <?php
                            // generate list of billboards
                            if(isset($all_items) && !empty($all_items)) { ?>
                                <dl class="billboard_map_list">
                                    <?php
                                    foreach($all_items as $item_info) {
                                        if($item_info->occupancy == 'occupied') {
                                            $text = '<div class="btn btn-success btn-xs">'.ucfirst($item_info->occupancy).'</div>';
                                        } else { 
                                            $text = '<div class="btn btn-warning btn-xs">'.ucfirst($item_info->occupancy).'</div>';
                                        }
                                        if($item_info->status == 1) { 
                                            $status = 'Active';
                                        } else { 
                                            $status = 'Inactive';
                                        }
                                        ?>
                                        <dt><?php echo $item_info->billboard_name; ?></dt>
                                        <dd>
                                            <?php
                                                echo $item_info->location.', '.$item_info->city.', '.$item_info->region.', '.$item_info->country.'<br />'.
                                                    // $item_info->latitude.', '.$item_info->longitude.' <br />'.
                                                    display_money($item_info->cost_per_month, $currency->symbol).' /'. $item_info->unit_type.'<br />'.
                                                    $status.' <br />'.
                                                    $text;
                                            ?> 
                                        </dd>
                                    <?php } ?>
                                </dl>
                            <?php } ?>
                        </div>

                        <?php if(isset($all_items) && !empty($all_items)) { ?>
                            <!-- Google Map Starts -->
                            <div id="gmap_canvas_details" class="col-md-8" style="height: 600px;"></div>
                            <script type="text/javascript">
                                // add generated coordinates to var locations
                                // array of coords generate
                                // $h_coords[] = "['hotel_name',lat,long,(int)star,'currency',(float)lowest price,'image[0]','base64_encoded(id)'],";
                                // [0,1,2,3,4,5,6,7]
                          
                                var locations = [
                                    <?php 
                                        foreach($all_items as $item_info) {
                                            echo "['".$item_info->billboard_name."', '".$item_info->latitude."', '".$item_info->longitude."', '".$item_info->occupancy."', '".$currency->code."', '".display_money($item_info->cost_per_month, $currency->symbol)."', '".$item_info->unit_type."', '".$item_info->billboard_id."'],"; 
                                        }
                                    ?>
                                    []
                                ];

                                var map = new google.maps.Map(document.getElementById('gmap_canvas_details'), {
                                  zoom: 7,
                                  // center: new google.maps.LatLng(-33.92, 151.25),
                                  center: new google.maps.LatLng(locations[0][1], locations[0][2]),
                                  mapTypeId: google.maps.MapTypeId.ROADMAP
                                });

                                var infowindow = new google.maps.InfoWindow();

                                var marker, i;

                                for (i = 0; i < locations.length; i++) {
                                    marker = new google.maps.Marker({
                                        position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                                        map: map
                                    });

                                    // set content for infowindow

                                    // prepare infowindow (google market pop up window)    
                                    google.maps.event.addListener(marker, 'click', (function(marker, i) {
                                        return function() {
                                          infowindow.setContent('<div class="map-infowindow">'+
                                            '<div class="map-image-frame">'+
                                                '<img alt="'+locations[i][0]+'" src="'+locations[i][6]+'" title="'+locations[i][0]+'" />'+
                                            '</div>'+
                                            '<div class="map-content">'+
                                                '<span class="map-title">'+locations[i][0]+'</span><br />'+
                                                '<span class="map-occupancy">'+locations[i][3]+'</span>'+
                                            '</div>'+
                                            // '<div class="map-pricing-frame"><strong>'+locations[i][4]+' '+locations[i][5]+'</strong><br />'+
                                            '<div class="map-pricing-frame">'+
                                                '<strong>'+locations[i][5]+'</strong> /'+locations[i][6]+'<br />'+
                                                '<div class="view-link">'+
                                                    '<a target="_blank" href="https://maps.google.com/maps?ll='+ locations[i][1] +','+ locations[i][2] +'&amp;z=7&amp;t=m&amp;hl=en-US&amp;gl=US&amp;mapclient=apiv3" tabindex="0"><span>View on Google Maps </span></a>'+
                                                '</div>'+
                                            '</div>'+
                                            '</div>');
                                          infowindow.open(map, marker);
                                        }
                                    })(marker, i));
                                    // open info window by default
                                    // infowindow.open(map, marker);
                                }
                            </script>
                            <!-- Google Map Ends -->
                        <?php } ?>
                    </div>
            </div>
        <?php } ?>
        </div>

<script type="text/javascript">
    function fetch_lat_long_from_google_maps() {
        var data = {};
        data.address = $('input[name="location"]').val();
        data.city = $('input[name="city"]').val();
        // data.country = $('select[name="country"] option:selected').text();
        data.country = $('select[name="country"] option:selected').val();
        console.log(data);
        $('#gmaps-search-icon').removeClass('fa-google').addClass('fa-spinner fa-spin');
        $.post('<?= base_url()?>admin/global_controller/fetch_address_info_gmaps', data).done(function (data) {
            data = JSON.parse(data);
            console.log(data);
            $('#gmaps-search-icon').removeClass('fa-spinner fa-spin').addClass('fa-google');
            if (null !== data.response && data.response.status == 'OK') {
                $('input[name="latitude"]').val(data.lat);
                $('input[name="longitude"]').val(data.lng);
                toastr.warning(data.response.status);
            } else {
                if (null !== data.response && data.response.status == 'ZERO_RESULTS') {
                    toastr.warning("<?php echo lang('g_search_address_not_found'); ?>");
                } else {
                    toastr.warning(data.response.status);
                }
            }
        });
    }
</script>