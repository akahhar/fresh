<div class="panel panel-custom">
    <div class="panel-heading">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
                class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel"><?= lang('add_billboards') ?></h4>
    </div>
    <div class="modal-body wrap-modal wrap">
        <form role="form" id="from_items"
              action="<?php echo base_url(); ?>admin/billboards/insert_billboard_items/<?= $module_id .'/'.$module; ?>" method="post"
              class="form-horizontal form-groups-bordered">

            <div class="form-group">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>
                            <div class="checkbox c-checkbox needsclick" >
                                <label class="needsclick" data-toggle="tooltip" title="<?= lang('select') . ' ' . lang('all') ?>">
                                    <input id="parent_present" type="checkbox" class="needsclick">
                                    <span class="fa fa-check"></span> </label>

                            </div>
                        </th>
                        <th><?= lang('name') ?></th>
                        <?php
                        $invoice_view = config_item('invoice_view');
                        if (!empty($invoice_view) && $invoice_view == '2') {
                            ?>
                            <th><?= lang('hsn_code') ?></th>
                        <?php } ?>
                        <th class="col-sm-2"><?= lang('location') ?></th>
                        <th class="col-sm-2"><?= lang('dimension') ?></th>
                        <th class="col-sm-2"><?= lang('orientation') ?></th>
                        <th class="col-sm-2"><?= lang('type') ?></th>
                        <th class="col-sm-2"><?= lang('faces') ?></th>
                        <th class="col-sm-2"><?= lang('charge') ?></th>
                        <th class="col-sm-2"><?= lang('tax') ?></th>
                        <th><?= lang('total') ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $saved_boards = $this->billboards_model->get_all_billboards();

                    if (!empty($saved_boards)) {
                        $saved_boards = array_reverse($saved_boards, true);
                        foreach ($saved_boards as $region => $v_saved_boards) { ?>
                            <tr>
                            <th colspan="11" style="font-size: 16px"><?= ucfirst($region); ?></th>
                            <?php
                            if (!empty($v_saved_boards)) {
                                foreach ($v_saved_boards as $v_item) {
                                    // skip occupied billboards
                                    if ($v_item->occupancy != 'vacant') continue; ?>
                                    <tr>
                                        <td>
                                            <div class="checkbox c-checkbox needsclick">
                                                <label class="needsclick">
                                                    <input class="child_present" type="checkbox" name="billboard_id[]"
                                                           value="<?= $v_item->billboard_id ?>"/>
                                                    <span class="fa fa-check"></span></label>
                                            </div>
                                        </td>
                                        <td><strong class="block"><?= $v_item->billboard_name ?></strong>
                                            <?php //echo strip_html_tags(mb_substr($v_item->description, 0, 200)) . '...'; ?>
                                        </td>
                                        <?php
                                        $invoice_view = config_item('invoice_view');
                                        if (!empty($invoice_view) && $invoice_view == '2') {
                                            ?>
                                            <td><?= $v_item->hsn_code ?></td>
                                        <?php } ?>
                                        <td><?= $v_item->location.', '.$v_item->city; ?></td>
                                        <td><?= $v_item->dimension ?></td>
                                        <td><?= ucfirst($v_item->orientation) ?></td>
                                        <td><?= ucfirst($v_item->type) ?></td>
                                        <td><?= $v_item->faces ?></td>
                                        <td><?= display_money($v_item->cost_per_month) . '<br />/' . $v_item->unit_type ?></td>
                                        <td><?php
                                            if (!is_numeric($v_item->tax_rates_id)) {
                                                $tax_rates = json_decode($v_item->tax_rates_id);
                                            } else {
                                                $tax_rates = null;
                                            }
                                            if (!empty($tax_rates)) {
                                                foreach ($tax_rates as $key => $tax_id) {
                                                    $taxes_info = $this->db->where('tax_rates_id', $tax_id)->get('tbl_tax_rates')->row();
                                                    if (!empty($taxes_info)) {
                                                        echo $key + 1 . '. ' . $taxes_info->tax_rate_name . '&nbsp;&nbsp; (' . $taxes_info->tax_rate_percent . '% ) <br>';
                                                    }
                                                }
                                            }
                                            ?>
                                        </td>
                                        <td><?= display_money($v_item->total_cost) ?></td>
                                    </tr>
                                <?php }
                            }
                            ?>
                            </tr>
                        <?php }
                    }; ?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?= lang('close') ?></button>
                <button type="submit" class="btn btn-primary"><?= lang('update') ?></button>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
    /*
     * Select All select
     */
    $(function () {
        $('#parent_present').on('change', function () {
            $('.child_present').prop('checked', $(this).prop('checked'));
        });
        $('.child_present').on('change', function () {
            $('.child_present').prop($('.child_present:checked').length ? true : false);
        });
    });
    $(document).ready(function () {
        $("#from_items").validate({
            rules: {
                billboard_id: {
                    required: true,
                }
            }
        });
    });</script>
<script src="<?php echo base_url(); ?>asset/js/custom-validation.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>asset/js/jquery.validate.js" type="text/javascript"></script>
