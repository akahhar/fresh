<?php
/**
 * Description of Billboards_Model
 *
 * @author NaYeM
 */
class Billboards_Model extends MY_Model
{

    public $_table_name;
    public $_order_by;
    public $_primary_key;

    // MY_model
    public function get_all_billboards()
    {
        $all_items = $this->db->get('tbl_billboards')->result();
        if (!empty($all_items)) {
            foreach ($all_items as $v_items) {
                $saved_items[$v_items->region][] = $v_items;
            }
        }
        if (!empty($saved_items)) {
            return $saved_items;
        } else {
            return array();
        }
    }

    // Global_controller
    /* Get billboard by id / ajax */
    // public function get_billboard_by_id($id)
    public function get_billboard_by_ajax($id)
    {
        if ($this->input->is_ajax_request()) {
            // $billboard = $this->admin_model->get_billboard_by_id($id);
            $billboard = $this->get_billboard_by_id($id);
            echo json_encode($billboard);
            exit();
        }
    }

    // Admin_model
    public function get_billboard_by_id($id = '')
    {
        $item = $this->db->where('billboard_id', $id)->get('tbl_billboards')->row();
        // $group = $this->db->where('customer_group_id', $item->customer_group_id)->get('tbl_customer_group')->row();
        $tax_info = json_decode($item->tax_rates_id);
        if (!empty($tax_info)) {
            foreach ($tax_info as $tax_id) {
                $tax = $this->db->where('tax_rates_id', $tax_id)->get('tbl_tax_rates')->row();
                $tax_name[] = $tax->tax_rate_name;
                $tax_rate[] = $tax->tax_rate_percent;
            }
        }

        // $groups = (object)[
        //     'group_name' => (!empty($group->customer_group) ? $group->customer_group : null),
        // ];

        $tax = (object)[
            'taxname' => (!empty($tax_name) ? json_encode($tax_name) : null),
            'taxrate' => (!empty($tax_rate) ? json_encode($tax_rate) : null),
        ];

        // return (object)array_merge((array)$item, (array)$groups, (array)$tax);
        return (object)array_merge((array)$item, (array)$tax);
    }
    
}
