<?php
defined('BASEPATH') or exit('No direct script access allowed');

$CI = &get_instance();

$CI->db->query("DELETE FROM `tbl_menu` WHERE `tbl_menu`.`label` = 'billboards'");

$CI->db->query("DROP TABLE IF EXISTS `tbl_billboards`");

$CI->db->query("DROP TABLE IF EXISTS `tbl_billboards_occupancy`");

$CI->db->query("ALTER TABLE `tbl_items` DROP COLUMN `billboard_id`");

$CI->db->query("ALTER TABLE `tbl_estimate_items` DROP COLUMN `billboard_id`");

