<?php
defined('BASEPATH') or exit('No direct script access allowed');

$CI = &get_instance();

// $CI->db->query("DELETE FROM `tbl_menu` WHERE `tbl_menu`.`label` = 'billboards'");

$CI->db->query("UPDATE `tbl_menu` SET `tbl_menu`.`status` = 0 WHERE `tbl_menu`.`label` = 'billboards'");
