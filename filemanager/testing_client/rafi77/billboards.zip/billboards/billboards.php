<?php defined('BASEPATH') or exit('No direct script access allowed');
/*
Module Name: Billboards - Billboards Management for ZiscoERP
Module ID: 32006555
Module URI: https://forwardsug.com
Description: Billboards - Billboards Management for ZiscoERP
Version: 1.0.0
Author: forwardsug
Author URI: https://codecanyon.net/user/forwardsug
Requires at least: 4.0.0
*/
define('BILLBOARDS_MODULE', 'billboards');

$CI = &get_instance();

module_languagesFiles(BILLBOARDS_MODULE, ['billboards']);

// $CI->module->css = [
//     'modules/' . BILLBOARDS_MODULE . '/assets/css/styles.css',
// ];

// $css_file = 'modules/' . BILLBOARDS_MODULE . '/assets/css/styles.css';
// array_push($CI->module->css, $css_file);

$CI->load->helper(BILLBOARDS_MODULE . '/billboards');
