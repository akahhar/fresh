<?php

defined('BASEPATH') or exit('No direct script access allowed');

/*
 * The file is responsible for handing the billboards installation
 */

$CI = &get_instance();


// Create the billboards menu
$CI->db->query(
    "INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`)
  VALUES (NULL, 'billboards', 'admin/billboards', 'fa fa-dashboard', '0', '10', CURRENT_TIMESTAMP, '1');"
);


// Create billboards table
// billboard_id, board_name, description, location, city, region, country, latitude, longitude, faces (1, 2, 3, 4), dimension, type, orientation, ownership*, cost_per_month*, occupancy*, last_occupied, image, date_added, date_updated, status (active or inactive)

$CI->db->query("DROP TABLE IF EXISTS `tbl_billboards;`");
$CI->db->query(
    "CREATE TABLE IF NOT EXISTS `tbl_billboards` (
        `billboard_id` int(11) NOT NULL AUTO_INCREMENT,
        `billboard_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
        `description` text COLLATE utf8_unicode_ci,
        `location` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
        `city` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
        `region` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
        `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
        `latitude` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
        `longitude` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
        `faces` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1, 2, 3 or 4',
        `dimension` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
        `type` enum('unipole','wall_scape') COLLATE utf8_unicode_ci DEFAULT 'unipole',
        `orientation` enum('portrait','landscape','square') COLLATE utf8_unicode_ci DEFAULT 'landscape',
        `ownership` enum('owned','leased') COLLATE utf8_unicode_ci DEFAULT 'owned',
        `cost_per_month` decimal(18,2) NOT NULL,
        `unit_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
        `tax_rates_id` int(11) DEFAULT NULL,
        `item_tax_rate` decimal(18,2) NOT NULL DEFAULT '0.00',
        `item_tax_total` decimal(18,2) NOT NULL DEFAULT '0.00',
        `total_cost` decimal(18,2) NOT NULL DEFAULT '0.00',
        `occupancy` enum('occupied','vacant') COLLATE utf8_unicode_ci DEFAULT 'vacant',
        `last_occupied` timestamp NULL DEFAULT NULL,
        `image` text COLLATE utf8_unicode_ci,
        `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `date_updated` timestamp NULL DEFAULT NULL,
        `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = inactive, 1 = active',
        PRIMARY KEY (`billboard_id`), UNIQUE KEY `billboard_id` (`billboard_id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"
);

// Usability (tbl_billboards_occupancy)
// occupancy_id, billboard_id, project_id, period, start_date, expiry_date, date_added, date_updated, status (pending, in_progress, on_hold, cancelled, completed)

$CI->db->query("DROP TABLE IF EXISTS `tbl_billboards_occupancy;`");
$CI->db->query(
    "CREATE TABLE IF NOT EXISTS `tbl_billboards_occupancy` (
        `occupancy_id` int(11) NOT NULL AUTO_INCREMENT,
        `billboard_id` int(11) NOT NULL DEFAULT '0',
        `project_id` int(11) NOT NULL,
        `period` int(2) NOT NULL,
        `start_date` datetime NOT NULL,
        `expiry_date` datetime NOT NULL,
        `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `date_updated` timestamp NULL DEFAULT NULL,
        `status` enum('pending','started','in_progress','on_hold','cancelled','completed') COLLATE utf8_unicode_ci DEFAULT 'pending',
        PRIMARY KEY (`occupancy_id`), UNIQUE KEY `occupancy_id` (`occupancy_id`)
    ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"
);

// add new table columns
$CI->db->query("ALTER TABLE `tbl_items` ADD `billboard_id` INT(11) NOT NULL DEFAULT 0 AFTER `saved_items_id` ");
$CI->db->query("ALTER TABLE `tbl_estimate_items` ADD `billboard_id` INT(11) NOT NULL DEFAULT 0 AFTER `saved_items_id` ");

// to include uploading the sample file (billboards_sample.xlsx)
