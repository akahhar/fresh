<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * billboards_lang.php file
 *
 */

$lang['billboard_occupied'] = 'Billboard Occupied';
$lang['sorry'] = 'Sorry!';
$lang['billboard_period_helper'] = 'In months e.g. 1, 2, 3, 4, 6, 12';
$lang['imported_new_billboards'] = 'Imported New Billboards';
$lang['vacant'] 	= 'Vacant';
$lang['occupied'] 	= 'Occupied';

$lang['activity_save_billboard_occupancy'] = 'Billboard occupancy saved';
$lang['activity_update_billboard_occupancy'] = 'Billboard occupancy updated';
$lang['activity_billboard_deleted'] = 'Deleted billboard';
$lang['activity_update_billboard'] 	= 'Updated billboard details';
$lang['activity_save_billboard'] 	= 'Saved billboard details';
$lang['delete_billboard'] 	= 'Billboard deleted';
$lang['save_billboard'] 	= 'Billboard Saved';
$lang['update_billboard'] 	= 'Billboard Updated';
$lang['billboard_unit_type_example'] = 'E.g. monthly, quarterly, bi-annually or annually';
// $lang['monthly'] = 'Monthly';
$lang['orientation'] 	= 'Orientation';
$lang['faces'] 			= 'Faces';
$lang['location_help'] 	= 'Plot Number, Street or Road Name';
$lang['billboard_name'] = 'Billboard Name';
$lang['cost_per_month'] = 'Cost Per Month';
$lang['ownership'] 		= 'Ownership';
$lang['dimension'] 		= 'Dimension';
$lang['occupancy'] 		= 'Occupancy';
$lang['billboard_details'] = 'Billboard Details';
$lang['new_billboard'] 	= 'New Billboard';
$lang['all_billboards'] = 'All Billboards';
$lang['add_billboard'] 	= 'Add Billboard';
$lang['add_billboards'] = 'Add Billboards';
$lang['billboards'] 	= 'Billboards';
$lang['billboard'] 		= 'Billboard';

